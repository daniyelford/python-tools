from api_info import req_handler

if __name__ == "__main__":
    req_handler()
